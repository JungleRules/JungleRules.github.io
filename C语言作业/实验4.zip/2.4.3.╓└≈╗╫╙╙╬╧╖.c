#include <stdio.h>
#include <stdlib.h> 
#include <time.h>
void news(int c)
{
	int e,f;
	int d=1;//��Ϊ������ 
	do{
    	e = rand()%6+1;
	    f = rand()%6+1;
	    printf("You Have %d + %d = %d",e,f,e+f);
	    if(e+f==c){
	    	printf("You Win!");
	    	break;
		} else {
			printf("Next!\n");
		}
		d++;
    }while(d<7);
    if(d==7){
        printf("Fault");	
	}
    return;
}
void number(int a,int b)
{
	int c = a+b;
	printf("You Have %d + %d = %d",a,b,c);
	switch(c)
	{
		case 2:
			printf("You Win!");
			return;
		case 3:
			printf("You Win!");
			return;	
		case 12:
			printf("You Win!");
			return;	
		case 7:
		    printf("You Fault!\n");
		    return;
		case 11:
		    printf("You Fault!\n");
		    return;
		default:
			printf("You Need Have %d\n",c);
            news(c);
			return;		    
	}
}
int main()
{
	srand(time(NULL));
	int a,b;
	a = rand()%6+1;
	b = rand()%6+1;
	number(a,b);
	return 0;
}
