#include <stdio.h>
int age(int n){
	if(n==1){
		return 10;
	} else if (n>1){
		return age(n-1)+2;
	}
}
int main()
{
	int n = 5;
	int a;
	a = age(n);
	printf("������%d",a);
	return 0;
}
