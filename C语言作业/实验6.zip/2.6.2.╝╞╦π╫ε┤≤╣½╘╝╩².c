#include <stdio.h>
int lbwnb(int a,int b){
	if(a<=-1||b<=-1){
		return -1;	
	} else if(a==b){
		return a;
	} else if (a>b){
		return lbwnb(a-b,b);
	} else if (b>a){
		return lbwnb(b-a,a);
	}
}
int main(){
	int a,b;
	scanf("%d,%d",&a,&b);
	printf("���Լ����%d",lbwnb(a,b));
	return 0;
}
