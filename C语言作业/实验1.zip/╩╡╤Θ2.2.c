//question2.2.c 
#include<stdio.h>
int main(void)
{
	char a,b;
	int c;
	scanf("%c%c%d",&a,&b,&c);
	//�޸������� 
	printf("%-3c%-2c%d\n",a,b,c);
	return 0;
}
