#include<stdio.h>
int main(void)
{
	char a,b;
	int c;
	scanf("%c%c%d",&a,&b,&c);
	printf("%c,%c,%d\n",a,b,c);
	return 0;
}
//question 1;��������ӦΪd 12 34 
