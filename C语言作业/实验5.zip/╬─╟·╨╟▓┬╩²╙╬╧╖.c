#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
	int lbwnb[4];
	//���������λ������ͬ����������ܼ򵥣������ĸ������ƴһ�𲻾͵��� 
	srand(time(NULL));
	lbwnb[0] = rand()%10;
	do{
		lbwnb[1]=rand()%10;
	}while(lbwnb[0]==lbwnb[1]);
	do{
		lbwnb[2]=rand()%10;
	}while(lbwnb[2]==lbwnb[1]||lbwnb[2]==lbwnb[0]);
	do{
		lbwnb[3]=rand()%10; 
	}while(lbwnb[3]==lbwnb[2]||lbwnb[3]==lbwnb[1]||lbwnb[3]==lbwnb[0]);
	int n;
	int m;//mΪ�²���� 
	scanf("%d",&m);
	
	int i = 0; 
	int x,y;
	do{
	    scanf("%d",&n);
	    x = 0;
	    y = 0;
	    int edg = n/1000;
	    if(edg ==lbwnb[0]) x++;
     	if(edg ==lbwnb[1]) y++;
    	if(edg ==lbwnb[2]) y++;
    	if(edg ==lbwnb[3]) y++;
    	n%=1000;
    	int dk = n/100;
    	if(dk ==lbwnb[0]) y++;
    	if(dk ==lbwnb[1]) x++;
    	if(dk ==lbwnb[2]) y++;
    	if(dk ==lbwnb[3]) y++;
    	n%=100;
    	int skt = n/10;
	    if(skt ==lbwnb[0]) y++;
	    if(skt ==lbwnb[1]) y++;
    	if(skt ==lbwnb[2]) x++;
     	if(skt ==lbwnb[3]) y++;
    	int gen = n%10;
    	if(gen ==lbwnb[0]) y++;
    	if(gen ==lbwnb[1]) y++;
    	if(gen ==lbwnb[2]) y++;
    	if(gen ==lbwnb[3]) x++;
    	printf("%dA%dB\n",x,y);
    		
    	if(x==4){
    		printf("Congratulations!");
    		break;
		}
    	i++;
    }while(i<m);
    if(i==m&&x!=4){
	    printf("Sorry,you haven't guess the right number!\n");
    	printf("%d%d%d%d",lbwnb[0],lbwnb[1],lbwnb[2],lbwnb[3]);
	}
	return 0;
}
